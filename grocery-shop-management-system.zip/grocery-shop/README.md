# GreenCart — Grocery Shop Management System

A complete grocery shop management system built with:

- **Frontend:** plain HTML, CSS, JavaScript (no framework, no Bootstrap)
- **Backend:** Python standard library only (`http.server`, `sqlite3`) — no Flask/Django
- **Database:** SQLite

## Features

- Attractive, responsive homepage with a search bar and featured products
- Full product management (add / edit / delete / view) with stock tracking
- Category management (create / edit / delete) with category-wise product filtering
- Client-side shopping cart (add / remove / update quantity, running total)
- Billing system: checkout generates an itemised bill, saved to SQLite
- Customer management (add, view, search by name/phone/email)
- Order history with per-order line items
- Low-stock alerts and a sales report (top products, totals, tax collected)

## Project structure

```
grocery-shop/
├── backend/
│   ├── server.py      # Pure-Python HTTP server, routing, static file serving
│   ├── models.py      # CRUD operations, validation, checkout/billing logic
│   └── database.py    # SQLite schema + seed data
├── frontend/
│   ├── index.html      # Homepage
│   ├── products.html   # Product listing, search & category filter
│   ├── cart.html        # Shopping cart + checkout + bill
│   ├── contact.html     # Contact page
│   ├── admin.html       # Admin dashboard (products/categories/customers/orders/reports)
│   ├── css/style.css
│   └── js/
│       ├── app.js       # Shared helpers: API calls, cart storage, toasts
│       ├── home.js
│       ├── products.js
│       ├── cart.js
│       └── admin.js
├── database/
│   └── grocery.db       # Created automatically on first run
└── README.md
```

## Running the app

Requirements: Python 3.8+ (no pip packages needed — everything is standard library).

```bash
cd grocery-shop/backend
python3 server.py            # starts on http://localhost:8000
# or choose a port:
python3 server.py 8080
```

Then open **http://localhost:8000/** in your browser.

The SQLite database (`database/grocery.db`) and its tables are created
automatically the first time the server starts, along with a few sample
categories and products so the site isn't empty on first load.

## Using the system

- **Home / Products / Categories** — browse and search the catalogue as a
  customer would; add items to your cart from any product card.
- **Cart** — adjust quantities, then "Proceed to checkout" to enter customer
  details and generate a bill. The bill is saved to the `bills` and `orders`
  tables and stock is decremented automatically.
- **Admin dashboard** (`admin.html`) — manage products and categories, view
  and search customers, browse order history, run a sales report for any
  date range, and check low-stock alerts.

## API overview

All endpoints return JSON and live under `/api`:

| Method | Endpoint                        | Purpose                          |
|--------|----------------------------------|-----------------------------------|
| GET    | /api/products                   | List products (supports `search`, `category_id`) |
| GET    | /api/products/low-stock         | Products at/below reorder threshold |
| POST   | /api/products                   | Create a product                 |
| PUT    | /api/products/{id}               | Update a product                 |
| DELETE | /api/products/{id}               | Delete a product                 |
| GET    | /api/categories                 | List categories                  |
| POST   | /api/categories                 | Create a category                |
| PUT    | /api/categories/{id}             | Update a category                |
| DELETE | /api/categories/{id}             | Delete a category                |
| GET    | /api/customers                  | List/search customers (`?search=`) |
| POST   | /api/customers                  | Create a customer                |
| POST   | /api/checkout                   | Place an order & generate a bill |
| GET    | /api/orders                     | Order history                    |
| GET    | /api/orders/{id}                 | Order detail with items          |
| GET    | /api/reports/sales               | Sales report (`?from=&to=`)      |

## Notes

- The cart is kept in the browser's `localStorage` until checkout, at which
  point it's sent to the server in a single request that validates stock,
  creates the customer/order/bill records, and decrements inventory
  atomically inside a SQLite transaction.
- All backend input is validated (required fields, numeric price/quantity,
  non-negative values, stock availability) and errors are returned as
  JSON with a matching HTTP status code (400 for validation, 404 for
  missing records).
