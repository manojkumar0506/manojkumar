/* products.js — products listing page: search + category filtering */

let ALL_CATEGORIES = [];
let currentSearch = "";
let currentCategoryId = "";

function productCardHtml(p) {
  const outOfStock = p.quantity <= 0;
  const low = !outOfStock && p.quantity <= (p.low_stock_threshold ?? 5);
  return `
  <div class="product-card">
    <div class="product-media">
      ${outOfStock ? '<span class="pill pill-danger badge">Out of stock</span>' : (low ? '<span class="pill pill-warn badge">Low stock</span>' : "")}
      <span>${productIcon(p.image)}</span>
    </div>
    <div class="product-body">
      <span class="product-category">${escapeHtml(p.category_name || "General")}</span>
      <span class="product-name">${escapeHtml(p.name)}</span>
      <p class="product-desc">${escapeHtml(p.description || "")}</p>
      <div class="product-foot">
        <span class="product-price">${formatCurrency(p.price)}</span>
        <button class="add-btn" ${outOfStock ? "disabled" : ""} title="Add to cart" data-id="${p.id}">+</button>
      </div>
      <span class="product-stock">${outOfStock ? "Currently unavailable" : p.quantity + " in stock"}</span>
    </div>
  </div>`;
}

function renderChips() {
  const chipsEl = document.getElementById("categoryChips");
  const chips = [`<span class="chip ${currentCategoryId === "" ? "active" : ""}" data-cat="">All items</span>`]
    .concat(
      ALL_CATEGORIES.map(
        (c) => `<span class="chip ${String(c.id) === String(currentCategoryId) ? "active" : ""}" data-cat="${c.id}">${escapeHtml(c.name)}</span>`
      )
    );
  chipsEl.innerHTML = chips.join("");
  chipsEl.querySelectorAll(".chip").forEach((chip) => {
    chip.addEventListener("click", () => {
      currentCategoryId = chip.dataset.cat;
      renderChips();
      loadProducts();
    });
  });
}

async function loadProducts() {
  const grid = document.getElementById("productGrid");
  grid.innerHTML = "<p>Loading products…</p>";
  try {
    let path = "/products?";
    const params = [];
    if (currentSearch) params.push("search=" + encodeURIComponent(currentSearch));
    if (currentCategoryId) params.push("category_id=" + encodeURIComponent(currentCategoryId));
    path += params.join("&");
    const products = await api.get(path);

    document.getElementById("resultsMeta").textContent =
      `${products.length} product${products.length === 1 ? "" : "s"} found` +
      (currentSearch ? ` for "${currentSearch}"` : "");

    if (products.length === 0) {
      grid.innerHTML = `<div class="empty-state" style="grid-column:1/-1;"><div class="emoji">🔍</div><p>No products matched your search. Try another keyword.</p></div>`;
      return;
    }
    grid.innerHTML = products.map(productCardHtml).join("");
    grid.querySelectorAll(".add-btn").forEach((btn) => {
      btn.addEventListener("click", () => {
        const product = products.find((p) => p.id === Number(btn.dataset.id));
        if (product) addToCart(product, 1);
      });
    });
  } catch (e) {
    grid.innerHTML = `<p>Could not load products: ${escapeHtml(e.message)}</p>`;
  }
}

async function init() {
  const urlParams = new URLSearchParams(window.location.search);
  currentSearch = urlParams.get("search") || "";
  currentCategoryId = urlParams.get("category_id") || "";
  document.getElementById("productSearchInput").value = currentSearch;

  try {
    ALL_CATEGORIES = await api.get("/categories");
  } catch (e) {
    ALL_CATEGORIES = [];
  }
  renderChips();
  loadProducts();

  document.getElementById("productSearchForm").addEventListener("submit", (e) => {
    e.preventDefault();
    currentSearch = document.getElementById("productSearchInput").value.trim();
    loadProducts();
  });
}

document.addEventListener("DOMContentLoaded", init);
