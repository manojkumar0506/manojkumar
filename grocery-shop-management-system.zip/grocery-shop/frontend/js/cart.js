/* cart.js — cart page rendering + checkout/billing flow */

const TAX_RATE = 0.05;

function cartItemHtml(item) {
  return `
  <div class="cart-item" data-id="${item.product_id}">
    <div class="icon">${productIcon(item.image)}</div>
    <div class="info">
      <b>${escapeHtml(item.name)}</b>
      <span>${formatCurrency(item.price)} each · ${item.available} available</span>
    </div>
    <div class="qty-control">
      <button class="qty-dec" aria-label="Decrease quantity">−</button>
      <span>${item.quantity}</span>
      <button class="qty-inc" aria-label="Increase quantity">+</button>
    </div>
    <button class="remove" title="Remove item">✕</button>
  </div>`;
}

function renderCart() {
  const cart = getCart();
  const listEl = document.getElementById("cartItemsList");

  if (cart.length === 0) {
    listEl.innerHTML = `<div class="empty-state"><div class="emoji">🛒</div><p>Your cart is empty.</p><a href="products.html" class="btn btn-primary">Browse products</a></div>`;
    document.getElementById("checkoutBtn").disabled = true;
  } else {
    listEl.innerHTML = cart.map(cartItemHtml).join("");
    document.getElementById("checkoutBtn").disabled = false;

    listEl.querySelectorAll(".cart-item").forEach((row) => {
      const id = Number(row.dataset.id);
      row.querySelector(".qty-inc").addEventListener("click", () => {
        const item = getCart().find((i) => i.product_id === id);
        setCartQuantity(id, item.quantity + 1);
        renderCart();
      });
      row.querySelector(".qty-dec").addEventListener("click", () => {
        const item = getCart().find((i) => i.product_id === id);
        setCartQuantity(id, item.quantity - 1);
        renderCart();
      });
      row.querySelector(".remove").addEventListener("click", () => {
        removeFromCart(id);
        renderCart();
      });
    });
  }

  const subtotal = cartTotalAmount();
  const tax = subtotal * TAX_RATE;
  document.getElementById("sumSubtotal").textContent = formatCurrency(subtotal);
  document.getElementById("sumTax").textContent = formatCurrency(tax);
  document.getElementById("sumTotal").textContent = formatCurrency(subtotal + tax);
}

function openModal(id) { document.getElementById(id).classList.add("open"); }
function closeModal(id) { document.getElementById(id).classList.remove("open"); }

function billHtml(bill) {
  const itemsHtml = bill.items
    .map(
      (it) => `<div class="bill-line"><span>${escapeHtml(it.name)} × ${it.quantity}</span><span>${formatCurrency(it.subtotal)}</span></div>`
    )
    .join("");
  return `
  <div class="bill-paper">
    <h3>GreenCart Grocers</h3>
    <div class="bill-sub">12 Market Street, Anna Nagar, Madurai · +91 98765 43210</div>
    <div class="bill-meta">
      <span>Bill No: <b>${escapeHtml(bill.bill_number)}</b></span>
      <span>${formatDate(bill.bill_date)}</span>
    </div>
    ${itemsHtml}
    <div class="bill-line" style="border-bottom:none;"><span>Subtotal</span><span>${formatCurrency(bill.subtotal)}</span></div>
    <div class="bill-line" style="border-bottom:none;"><span>Tax (${Math.round(bill.tax_rate * 100)}%)</span><span>${formatCurrency(bill.tax)}</span></div>
    <div class="bill-line" style="border-bottom:none;font-weight:700;font-size:1.05rem;"><span>Total</span><span>${formatCurrency(bill.total_amount)}</span></div>
    <p style="text-align:center;margin-top:16px;font-size:0.85rem;">Thank you for shopping with GreenCart!</p>
  </div>`;
}

async function submitCheckout(e) {
  e.preventDefault();
  const cart = getCart();
  if (cart.length === 0) return;

  const btn = document.getElementById("confirmCheckoutBtn");
  btn.disabled = true;
  btn.textContent = "Placing order…";

  const payload = {
    customer: {
      name: document.getElementById("custName").value.trim(),
      phone: document.getElementById("custPhone").value.trim(),
      email: document.getElementById("custEmail").value.trim(),
      address: document.getElementById("custAddress").value.trim(),
    },
    items: cart.map((i) => ({ product_id: i.product_id, quantity: i.quantity })),
    tax_rate: TAX_RATE,
  };

  try {
    const bill = await api.post("/checkout", payload);
    closeModal("checkoutModal");
    document.getElementById("billContent").innerHTML = billHtml(bill);
    openModal("billModal");
    clearCart();
    renderCart();
    toast("Order placed and bill generated!");
  } catch (err) {
    toast(err.message, "error");
  } finally {
    btn.disabled = false;
    btn.textContent = "Generate bill";
  }
}

function init() {
  renderCart();
  document.getElementById("checkoutBtn").addEventListener("click", () => openModal("checkoutModal"));
  document.getElementById("closeCheckoutModal").addEventListener("click", () => closeModal("checkoutModal"));
  document.getElementById("closeBillModal").addEventListener("click", () => closeModal("billModal"));
  document.getElementById("checkoutForm").addEventListener("submit", submitCheckout);
  document.getElementById("printBillBtn").addEventListener("click", () => window.print());

  [document.getElementById("checkoutModal"), document.getElementById("billModal")].forEach((backdrop) => {
    backdrop.addEventListener("click", (e) => {
      if (e.target === backdrop) backdrop.classList.remove("open");
    });
  });
}

document.addEventListener("DOMContentLoaded", init);
