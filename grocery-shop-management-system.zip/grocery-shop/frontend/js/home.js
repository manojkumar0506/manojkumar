/* home.js — populate homepage categories & featured products */

function categoryChipHtml(cat) {
  return `<a class="chip" href="products.html?category_id=${cat.id}">${escapeHtml(cat.name)} <span style="opacity:.6">(${cat.product_count})</span></a>`;
}

function productCardHtml(p) {
  const outOfStock = p.quantity <= 0;
  const low = !outOfStock && p.quantity <= (p.low_stock_threshold ?? 5);
  return `
  <div class="product-card">
    <div class="product-media">
      ${outOfStock ? '<span class="pill pill-danger badge">Out of stock</span>' : (low ? '<span class="pill pill-warn badge">Low stock</span>' : "")}
      <span>${productIcon(p.image)}</span>
    </div>
    <div class="product-body">
      <span class="product-category">${escapeHtml(p.category_name || "General")}</span>
      <span class="product-name">${escapeHtml(p.name)}</span>
      <p class="product-desc">${escapeHtml(p.description || "")}</p>
      <div class="product-foot">
        <span class="product-price">${formatCurrency(p.price)}</span>
        <button class="add-btn" ${outOfStock ? "disabled" : ""} title="Add to cart" data-id="${p.id}">+</button>
      </div>
      <span class="product-stock">${outOfStock ? "Currently unavailable" : p.quantity + " in stock"}</span>
    </div>
  </div>`;
}

function wireAddButtons(container, products) {
  container.querySelectorAll(".add-btn").forEach((btn) => {
    btn.addEventListener("click", () => {
      const product = products.find((p) => p.id === Number(btn.dataset.id));
      if (product) addToCart(product, 1);
    });
  });
}

async function loadHome() {
  try {
    const categories = await api.get("/categories");
    document.getElementById("statCategories").textContent = categories.length;
    const chipsEl = document.getElementById("categoryChips");
    chipsEl.innerHTML = categories.map(categoryChipHtml).join("");
  } catch (e) {
    console.error(e);
  }

  try {
    const products = await api.get("/products");
    document.getElementById("statProducts").textContent = products.length;
    const featured = products.slice().sort((a, b) => b.quantity - a.quantity).slice(0, 8);
    const grid = document.getElementById("featuredGrid");
    grid.innerHTML = featured.map(productCardHtml).join("");
    wireAddButtons(grid, featured);
  } catch (e) {
    document.getElementById("featuredGrid").innerHTML = `<p>Could not load products right now.</p>`;
    console.error(e);
  }
}

document.addEventListener("DOMContentLoaded", loadHome);
