/* =========================================================================
   app.js — shared utilities used across every page
   (API calls, cart storage, toasts, header behaviour, product icons)
   ========================================================================= */

const API_BASE = "/api";

/* ------------------------------------------------------------ API layer */
async function apiRequest(method, path, body) {
  const options = { method, headers: {} };
  if (body !== undefined) {
    options.headers["Content-Type"] = "application/json";
    options.body = JSON.stringify(body);
  }
  const res = await fetch(API_BASE + path, options);
  let data = null;
  try {
    data = await res.json();
  } catch (e) {
    data = null;
  }
  if (!res.ok) {
    const message = (data && data.error) || `Request failed (${res.status})`;
    throw new Error(message);
  }
  return data;
}

const api = {
  get: (path) => apiRequest("GET", path),
  post: (path, body) => apiRequest("POST", path, body),
  put: (path, body) => apiRequest("PUT", path, body),
  del: (path) => apiRequest("DELETE", path),
};

/* -------------------------------------------------------------- toasts */
function toast(message, type = "success") {
  let root = document.getElementById("toast-root");
  if (!root) {
    root = document.createElement("div");
    root.id = "toast-root";
    document.body.appendChild(root);
  }
  const el = document.createElement("div");
  el.className = "toast" + (type === "error" ? " error" : "");
  el.textContent = message;
  root.appendChild(el);
  setTimeout(() => el.remove(), 3200);
}

/* ------------------------------------------------------- product icons */
const PRODUCT_ICONS = {
  apple: "🍎", banana: "🍌", tomato: "🍅", potato: "🥔", carrot: "🥕",
  milk: "🥛", cheese: "🧀", egg: "🥚", curd: "🥣", bread: "🍞",
  cake: "🍰", croissant: "🥐", juice: "🧃", water: "💧", soda: "🥤",
  chips: "🥔", biscuit: "🍪", peanuts: "🥜", rice: "🍚", dal: "🫘",
  flour: "🌾", default: "🛒",
};
function productIcon(name) {
  return PRODUCT_ICONS[(name || "").toLowerCase()] || PRODUCT_ICONS.default;
}

/* ------------------------------------------------------------ formatting */
function formatCurrency(amount) {
  const n = Number(amount) || 0;
  return "₹" + n.toLocaleString("en-IN", { minimumFractionDigits: 2, maximumFractionDigits: 2 });
}
function formatDate(iso) {
  if (!iso) return "";
  const d = new Date(iso.replace(" ", "T"));
  if (isNaN(d)) return iso;
  return d.toLocaleString("en-IN", { day: "2-digit", month: "short", year: "numeric", hour: "2-digit", minute: "2-digit" });
}
function escapeHtml(str) {
  return String(str ?? "").replace(/[&<>"']/g, (c) => ({
    "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;",
  }[c]));
}

/* ------------------------------------------------------------------ cart
   Cart is stored client-side in localStorage as:
   [{ product_id, name, price, image, quantity, available }]
   It only talks to the server at checkout time. */
const CART_KEY = "greencart_cart";

function getCart() {
  try {
    return JSON.parse(localStorage.getItem(CART_KEY)) || [];
  } catch (e) {
    return [];
  }
}
function saveCart(cart) {
  localStorage.setItem(CART_KEY, JSON.stringify(cart));
  updateCartBadge();
}
function cartCount() {
  return getCart().reduce((sum, i) => sum + i.quantity, 0);
}
function cartTotalAmount() {
  return getCart().reduce((sum, i) => sum + i.quantity * i.price, 0);
}
function addToCart(product, qty = 1) {
  const cart = getCart();
  const existing = cart.find((i) => i.product_id === product.id);
  const available = product.quantity;
  if (existing) {
    if (existing.quantity + qty > available) {
      toast(`Only ${available} in stock for ${product.name}`, "error");
      return;
    }
    existing.quantity += qty;
  } else {
    if (qty > available) {
      toast(`Only ${available} in stock for ${product.name}`, "error");
      return;
    }
    cart.push({
      product_id: product.id,
      name: product.name,
      price: product.price,
      image: product.image,
      quantity: qty,
      available: available,
    });
  }
  saveCart(cart);
  toast(`${product.name} added to cart`);
}
function removeFromCart(productId) {
  saveCart(getCart().filter((i) => i.product_id !== productId));
}
function setCartQuantity(productId, qty) {
  let cart = getCart();
  const item = cart.find((i) => i.product_id === productId);
  if (!item) return;
  if (qty <= 0) {
    cart = cart.filter((i) => i.product_id !== productId);
  } else if (qty > item.available) {
    toast(`Only ${item.available} in stock`, "error");
    return;
  } else {
    item.quantity = qty;
  }
  saveCart(cart);
}
function clearCart() {
  saveCart([]);
}
function updateCartBadge() {
  document.querySelectorAll(".cart-count").forEach((el) => {
    el.textContent = cartCount();
  });
}

/* --------------------------------------------------------- layout / nav */
function markActiveNav() {
  const page = document.body.getAttribute("data-page");
  document.querySelectorAll(".main-nav a[data-nav]").forEach((a) => {
    a.classList.toggle("active", a.getAttribute("data-nav") === page);
  });
}
function initNavToggle() {
  const toggle = document.getElementById("navToggle");
  const nav = document.getElementById("mainNav");
  if (toggle && nav) {
    toggle.addEventListener("click", () => nav.classList.toggle("open"));
  }
}
function initHeaderSearch() {
  const form = document.getElementById("headerSearchForm");
  if (!form) return;
  form.addEventListener("submit", (e) => {
    e.preventDefault();
    const q = form.querySelector("input").value.trim();
    window.location.href = "products.html" + (q ? `?search=${encodeURIComponent(q)}` : "");
  });
}

document.addEventListener("DOMContentLoaded", () => {
  updateCartBadge();
  markActiveNav();
  initNavToggle();
  initHeaderSearch();
});
