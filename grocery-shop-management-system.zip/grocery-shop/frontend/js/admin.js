/* admin.js — Admin dashboard: products, categories, customers, orders, reports */

let CATEGORIES_CACHE = [];

/* ------------------------------------------------------------- tabs */
function initTabs() {
  document.querySelectorAll(".tab-btn").forEach((btn) => {
    btn.addEventListener("click", () => {
      document.querySelectorAll(".tab-btn").forEach((b) => b.classList.remove("active"));
      document.querySelectorAll(".tab-panel").forEach((p) => p.classList.remove("active"));
      btn.classList.add("active");
      document.getElementById("tab-" + btn.dataset.tab).classList.add("active");
    });
  });
}

function openModal(id) { document.getElementById(id).classList.add("open"); }
function closeModal(id) { document.getElementById(id).classList.remove("open"); }

function initModalClosers() {
  document.querySelectorAll(".modal-close").forEach((btn) => {
    btn.addEventListener("click", () => closeModal(btn.dataset.close));
  });
  document.querySelectorAll(".modal-backdrop").forEach((backdrop) => {
    backdrop.addEventListener("click", (e) => {
      if (e.target === backdrop) backdrop.classList.remove("open");
    });
  });
}

/* --------------------------------------------------------- dashboard stats */
async function loadStats() {
  try {
    const [products, customers, lowStock, report] = await Promise.all([
      api.get("/products"),
      api.get("/customers"),
      api.get("/products/low-stock"),
      api.get("/reports/sales"),
    ]);
    document.getElementById("statTotalProducts").textContent = products.length;
    document.getElementById("statLowStock").textContent = lowStock.length;
    document.getElementById("statTotalCustomers").textContent = customers.length;
    document.getElementById("statTotalSales").textContent = formatCurrency(report.total_sales);
  } catch (e) {
    console.error(e);
  }
}

/* ================================================================ PRODUCTS */
function statusPill(p) {
  if (p.quantity <= 0) return '<span class="pill pill-danger">Out of stock</span>';
  if (p.quantity <= p.low_stock_threshold) return '<span class="pill pill-warn">Low stock</span>';
  return '<span class="pill">In stock</span>';
}

async function loadProductsTable() {
  const tbody = document.getElementById("productsTableBody");
  tbody.innerHTML = `<tr><td colspan="7">Loading…</td></tr>`;
  try {
    const products = await api.get("/products");
    if (products.length === 0) {
      tbody.innerHTML = `<tr><td colspan="7">No products yet. Add your first one.</td></tr>`;
      return;
    }
    tbody.innerHTML = products
      .map(
        (p) => `
      <tr>
        <td>${p.id}</td>
        <td>${escapeHtml(p.name)}</td>
        <td>${escapeHtml(p.category_name || "—")}</td>
        <td>${formatCurrency(p.price)}</td>
        <td>${p.quantity}</td>
        <td>${statusPill(p)}</td>
        <td class="row-actions">
          <button class="btn btn-outline btn-sm" data-edit="${p.id}">Edit</button>
          <button class="btn btn-danger btn-sm" data-delete="${p.id}">Delete</button>
        </td>
      </tr>`
      )
      .join("");

    tbody.querySelectorAll("[data-edit]").forEach((btn) =>
      btn.addEventListener("click", () => openProductModal(products.find((p) => p.id === Number(btn.dataset.edit))))
    );
    tbody.querySelectorAll("[data-delete]").forEach((btn) =>
      btn.addEventListener("click", () => deleteProduct(Number(btn.dataset.delete)))
    );
  } catch (e) {
    tbody.innerHTML = `<tr><td colspan="7">Error loading products: ${escapeHtml(e.message)}</td></tr>`;
  }
}

function populateCategorySelect() {
  const select = document.getElementById("pCategory");
  select.innerHTML =
    `<option value="">Uncategorised</option>` +
    CATEGORIES_CACHE.map((c) => `<option value="${c.id}">${escapeHtml(c.name)}</option>`).join("");
}

function openProductModal(product) {
  populateCategorySelect();
  document.getElementById("productModalTitle").textContent = product ? "Edit product" : "Add product";
  document.getElementById("productId").value = product ? product.id : "";
  document.getElementById("pName").value = product ? product.name : "";
  document.getElementById("pCategory").value = product ? (product.category_id || "") : "";
  document.getElementById("pImage").value = product ? (product.image || "") : "";
  document.getElementById("pPrice").value = product ? product.price : "";
  document.getElementById("pQuantity").value = product ? product.quantity : "";
  document.getElementById("pThreshold").value = product ? product.low_stock_threshold : 5;
  document.getElementById("pDescription").value = product ? (product.description || "") : "";
  openModal("productModal");
}

async function saveProduct(e) {
  e.preventDefault();
  const id = document.getElementById("productId").value;
  const payload = {
    name: document.getElementById("pName").value.trim(),
    category_id: document.getElementById("pCategory").value || null,
    image: document.getElementById("pImage").value.trim() || "default",
    price: parseFloat(document.getElementById("pPrice").value),
    quantity: parseInt(document.getElementById("pQuantity").value, 10),
    low_stock_threshold: parseInt(document.getElementById("pThreshold").value || "5", 10),
    description: document.getElementById("pDescription").value.trim(),
  };
  try {
    if (id) {
      await api.put(`/products/${id}`, payload);
      toast("Product updated");
    } else {
      await api.post("/products", payload);
      toast("Product added");
    }
    closeModal("productModal");
    loadProductsTable();
    loadStats();
    loadLowStockTable();
  } catch (err) {
    toast(err.message, "error");
  }
}

async function deleteProduct(id) {
  if (!confirm("Delete this product? This cannot be undone.")) return;
  try {
    await api.del(`/products/${id}`);
    toast("Product deleted");
    loadProductsTable();
    loadStats();
    loadLowStockTable();
  } catch (err) {
    toast(err.message, "error");
  }
}

/* ============================================================== CATEGORIES */
async function loadCategoriesTable() {
  const tbody = document.getElementById("categoriesTableBody");
  tbody.innerHTML = `<tr><td colspan="5">Loading…</td></tr>`;
  try {
    const categories = await api.get("/categories");
    CATEGORIES_CACHE = categories;
    if (categories.length === 0) {
      tbody.innerHTML = `<tr><td colspan="5">No categories yet.</td></tr>`;
      return;
    }
    tbody.innerHTML = categories
      .map(
        (c) => `
      <tr>
        <td>${c.id}</td>
        <td>${escapeHtml(c.name)}</td>
        <td>${escapeHtml(c.description || "—")}</td>
        <td>${c.product_count}</td>
        <td class="row-actions">
          <button class="btn btn-outline btn-sm" data-edit="${c.id}">Edit</button>
          <button class="btn btn-danger btn-sm" data-delete="${c.id}">Delete</button>
        </td>
      </tr>`
      )
      .join("");

    tbody.querySelectorAll("[data-edit]").forEach((btn) =>
      btn.addEventListener("click", () => openCategoryModal(categories.find((c) => c.id === Number(btn.dataset.edit))))
    );
    tbody.querySelectorAll("[data-delete]").forEach((btn) =>
      btn.addEventListener("click", () => deleteCategory(Number(btn.dataset.delete)))
    );
  } catch (e) {
    tbody.innerHTML = `<tr><td colspan="5">Error loading categories: ${escapeHtml(e.message)}</td></tr>`;
  }
}

function openCategoryModal(category) {
  document.getElementById("categoryModalTitle").textContent = category ? "Edit category" : "Add category";
  document.getElementById("categoryId").value = category ? category.id : "";
  document.getElementById("catName").value = category ? category.name : "";
  document.getElementById("catDescription").value = category ? (category.description || "") : "";
  openModal("categoryModal");
}

async function saveCategory(e) {
  e.preventDefault();
  const id = document.getElementById("categoryId").value;
  const payload = {
    name: document.getElementById("catName").value.trim(),
    description: document.getElementById("catDescription").value.trim(),
  };
  try {
    if (id) {
      await api.put(`/categories/${id}`, payload);
      toast("Category updated");
    } else {
      await api.post("/categories", payload);
      toast("Category added");
    }
    closeModal("categoryModal");
    loadCategoriesTable();
    loadProductsTable();
  } catch (err) {
    toast(err.message, "error");
  }
}

async function deleteCategory(id) {
  if (!confirm("Delete this category? Products in it will become uncategorised.")) return;
  try {
    await api.del(`/categories/${id}`);
    toast("Category deleted");
    loadCategoriesTable();
    loadProductsTable();
  } catch (err) {
    toast(err.message, "error");
  }
}

/* =============================================================== CUSTOMERS */
async function loadCustomersTable(search) {
  const tbody = document.getElementById("customersTableBody");
  tbody.innerHTML = `<tr><td colspan="6">Loading…</td></tr>`;
  try {
    const path = search ? `/customers?search=${encodeURIComponent(search)}` : "/customers";
    const customers = await api.get(path);
    if (customers.length === 0) {
      tbody.innerHTML = `<tr><td colspan="6">No customers found.</td></tr>`;
      return;
    }
    tbody.innerHTML = customers
      .map(
        (c) => `
      <tr>
        <td>${c.id}</td>
        <td>${escapeHtml(c.name)}</td>
        <td>${escapeHtml(c.phone || "—")}</td>
        <td>${escapeHtml(c.email || "—")}</td>
        <td>${escapeHtml(c.address || "—")}</td>
        <td>${formatDate(c.created_at)}</td>
      </tr>`
      )
      .join("");
  } catch (e) {
    tbody.innerHTML = `<tr><td colspan="6">Error loading customers: ${escapeHtml(e.message)}</td></tr>`;
  }
}

async function saveCustomer(e) {
  e.preventDefault();
  const payload = {
    name: document.getElementById("custFormName").value.trim(),
    phone: document.getElementById("custFormPhone").value.trim(),
    email: document.getElementById("custFormEmail").value.trim(),
    address: document.getElementById("custFormAddress").value.trim(),
  };
  try {
    await api.post("/customers", payload);
    toast("Customer added");
    closeModal("customerModal");
    document.getElementById("customerForm").reset();
    loadCustomersTable();
    loadStats();
  } catch (err) {
    toast(err.message, "error");
  }
}

/* ================================================================= ORDERS */
async function loadOrdersTable() {
  const tbody = document.getElementById("ordersTableBody");
  tbody.innerHTML = `<tr><td colspan="6">Loading…</td></tr>`;
  try {
    const orders = await api.get("/orders");
    if (orders.length === 0) {
      tbody.innerHTML = `<tr><td colspan="6">No orders placed yet.</td></tr>`;
      return;
    }
    tbody.innerHTML = orders
      .map(
        (o) => `
      <tr>
        <td>${escapeHtml(o.bill_number || "—")}</td>
        <td>${escapeHtml(o.customer_name || "Walk-in")}</td>
        <td>${escapeHtml(o.customer_phone || "—")}</td>
        <td>${formatDate(o.order_date)}</td>
        <td>${formatCurrency(o.total_amount)}</td>
        <td><button class="btn btn-outline btn-sm" data-view="${o.id}">View</button></td>
      </tr>`
      )
      .join("");

    tbody.querySelectorAll("[data-view]").forEach((btn) =>
      btn.addEventListener("click", () => viewOrder(Number(btn.dataset.view)))
    );
  } catch (e) {
    tbody.innerHTML = `<tr><td colspan="6">Error loading orders: ${escapeHtml(e.message)}</td></tr>`;
  }
}

async function viewOrder(id) {
  try {
    const order = await api.get(`/orders/${id}`);
    const itemsHtml = order.items
      .map((it) => `<div class="bill-line"><span>${escapeHtml(it.product_name)} × ${it.quantity}</span><span>${formatCurrency(it.subtotal)}</span></div>`)
      .join("");
    document.getElementById("orderModalContent").innerHTML = `
      <p><b>Customer:</b> ${escapeHtml(order.customer_name || "Walk-in")} (${escapeHtml(order.customer_phone || "—")})</p>
      <p><b>Bill number:</b> ${escapeHtml(order.bill_number || "—")}</p>
      <p><b>Date:</b> ${formatDate(order.order_date)}</p>
      <div class="panel" style="box-shadow:none;padding:16px;background:var(--paper);">
        ${itemsHtml}
        <div class="bill-line" style="border-bottom:none;"><span>Subtotal</span><span>${formatCurrency(order.subtotal)}</span></div>
        <div class="bill-line" style="border-bottom:none;"><span>Tax</span><span>${formatCurrency(order.tax)}</span></div>
        <div class="bill-line" style="border-bottom:none;font-weight:700;"><span>Total</span><span>${formatCurrency(order.bill_total)}</span></div>
      </div>`;
    openModal("orderModal");
  } catch (e) {
    toast(e.message, "error");
  }
}

/* ================================================================ REPORTS */
async function runSalesReport() {
  const from = document.getElementById("reportFrom").value;
  const to = document.getElementById("reportTo").value;
  let path = "/reports/sales?";
  const params = [];
  if (from) params.push("from=" + from);
  if (to) params.push("to=" + to);
  path += params.join("&");

  try {
    const report = await api.get(path);
    document.getElementById("rptBills").textContent = report.total_bills;
    document.getElementById("rptSales").textContent = formatCurrency(report.total_sales);
    document.getElementById("rptTax").textContent = formatCurrency(report.total_tax);

    const body = document.getElementById("topProductsBody");
    if (report.top_products.length === 0) {
      body.innerHTML = `<tr><td colspan="3">No sales in this range yet.</td></tr>`;
    } else {
      body.innerHTML = report.top_products
        .map((p) => `<tr><td>${escapeHtml(p.product_name)}</td><td>${p.units_sold}</td><td>${formatCurrency(p.revenue)}</td></tr>`)
        .join("");
    }
  } catch (e) {
    toast(e.message, "error");
  }
}

/* ============================================================== LOW STOCK */
async function loadLowStockTable() {
  const tbody = document.getElementById("lowStockTableBody");
  tbody.innerHTML = `<tr><td colspan="4">Loading…</td></tr>`;
  try {
    const items = await api.get("/products/low-stock");
    if (items.length === 0) {
      tbody.innerHTML = `<tr><td colspan="4">Everything is well stocked. 🎉</td></tr>`;
      return;
    }
    tbody.innerHTML = items
      .map(
        (p) => `
      <tr>
        <td>${escapeHtml(p.name)}</td>
        <td>${escapeHtml(p.category_name || "—")}</td>
        <td>${p.quantity}</td>
        <td>${p.low_stock_threshold}</td>
      </tr>`
      )
      .join("");
  } catch (e) {
    tbody.innerHTML = `<tr><td colspan="4">Error: ${escapeHtml(e.message)}</td></tr>`;
  }
}

/* ==================================================================== init */
function init() {
  initTabs();
  initModalClosers();

  document.getElementById("addProductBtn").addEventListener("click", () => openProductModal(null));
  document.getElementById("productForm").addEventListener("submit", saveProduct);

  document.getElementById("addCategoryBtn").addEventListener("click", () => openCategoryModal(null));
  document.getElementById("categoryForm").addEventListener("submit", saveCategory);

  document.getElementById("addCustomerBtn").addEventListener("click", () => openModal("customerModal"));
  document.getElementById("customerForm").addEventListener("submit", saveCustomer);
  document.getElementById("customerSearchInput").addEventListener("input", (e) => {
    clearTimeout(window._custSearchTimer);
    window._custSearchTimer = setTimeout(() => loadCustomersTable(e.target.value.trim()), 300);
  });

  document.getElementById("runReportBtn").addEventListener("click", runSalesReport);

  loadStats();
  loadCategoriesTable().then(() => loadProductsTable());
  loadCustomersTable();
  loadOrdersTable();
  loadLowStockTable();
  runSalesReport();
}

document.addEventListener("DOMContentLoaded", init);
