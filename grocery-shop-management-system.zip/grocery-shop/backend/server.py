"""
server.py
---------
Pure-Python backend for the Grocery Shop Management System.

No web framework is used - this relies solely on Python's built-in
http.server module. It serves the static frontend (HTML/CSS/JS) and
exposes a small JSON REST API under /api/* backed by SQLite.

Run with:  python server.py [port]
Then open: http://localhost:8000/
"""

import json
import os
import re
import sys
import mimetypes
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from urllib.parse import urlparse, parse_qs

import database
import models
from models import ValidationError, NotFoundError

BASE_DIR = os.path.dirname(os.path.abspath(__file__))
FRONTEND_DIR = os.path.join(os.path.dirname(BASE_DIR), "frontend")

DEFAULT_PORT = 8000


# --------------------------------------------------------------------------
# Routing table: (HTTP_METHOD, compiled regex, handler_name)
# Named groups in the regex are passed as keyword args to the handler.
# --------------------------------------------------------------------------
ROUTES = []


def route(method, pattern):
    regex = re.compile("^" + pattern + "$")

    def decorator(func):
        ROUTES.append((method, regex, func))
        return func

    return decorator


# ============================================================ CATEGORIES ==
@route("GET", r"/api/categories")
def api_list_categories(handler, query):
    return 200, models.list_categories()


@route("GET", r"/api/categories/(?P<id>\d+)")
def api_get_category(handler, query, id):
    return 200, models.get_category(int(id))


@route("GET", r"/api/categories/(?P<id>\d+)/products")
def api_category_products(handler, query, id):
    return 200, models.list_products(category_id=int(id))


@route("POST", r"/api/categories")
def api_create_category(handler, query, body):
    return 201, models.create_category(body)


@route("PUT", r"/api/categories/(?P<id>\d+)")
def api_update_category(handler, query, body, id):
    return 200, models.update_category(int(id), body)


@route("DELETE", r"/api/categories/(?P<id>\d+)")
def api_delete_category(handler, query, id):
    models.delete_category(int(id))
    return 200, {"message": "Category deleted"}


# ============================================================== PRODUCTS ==
@route("GET", r"/api/products")
def api_list_products(handler, query):
    search = (query.get("search") or [None])[0]
    category_id = (query.get("category_id") or [None])[0]
    return 200, models.list_products(search=search, category_id=category_id)


@route("GET", r"/api/products/low-stock")
def api_low_stock(handler, query):
    return 200, models.low_stock_products()


@route("GET", r"/api/products/(?P<id>\d+)")
def api_get_product(handler, query, id):
    return 200, models.get_product(int(id))


@route("POST", r"/api/products")
def api_create_product(handler, query, body):
    return 201, models.create_product(body)


@route("PUT", r"/api/products/(?P<id>\d+)")
def api_update_product(handler, query, body, id):
    return 200, models.update_product(int(id), body)


@route("DELETE", r"/api/products/(?P<id>\d+)")
def api_delete_product(handler, query, id):
    models.delete_product(int(id))
    return 200, {"message": "Product deleted"}


# ============================================================= CUSTOMERS ==
@route("GET", r"/api/customers")
def api_list_customers(handler, query):
    search = (query.get("search") or [None])[0]
    if search:
        return 200, models.search_customers(search)
    return 200, models.list_customers()


@route("GET", r"/api/customers/(?P<id>\d+)")
def api_get_customer(handler, query, id):
    return 200, models.get_customer(int(id))


@route("POST", r"/api/customers")
def api_create_customer(handler, query, body):
    return 201, models.create_customer(body)


# ======================================================= ORDERS / BILLS ==
@route("POST", r"/api/checkout")
def api_checkout(handler, query, body):
    return 201, models.checkout(body)


@route("GET", r"/api/orders")
def api_list_orders(handler, query):
    return 200, models.list_orders()


@route("GET", r"/api/orders/(?P<id>\d+)")
def api_get_order(handler, query, id):
    return 200, models.get_order(int(id))


# ================================================================ REPORTS ==
@route("GET", r"/api/reports/sales")
def api_sales_report(handler, query):
    date_from = (query.get("from") or [None])[0]
    date_to = (query.get("to") or [None])[0]
    return 200, models.sales_report(date_from, date_to)


# --------------------------------------------------------------------------
# Static file serving
# --------------------------------------------------------------------------
def serve_static(handler, path):
    if path == "/":
        path = "/index.html"
    safe_path = os.path.normpath(path).lstrip("/\\")
    full_path = os.path.join(FRONTEND_DIR, safe_path)

    # Prevent path traversal outside frontend directory
    if not os.path.abspath(full_path).startswith(os.path.abspath(FRONTEND_DIR)):
        handler.send_error(403, "Forbidden")
        return

    if not os.path.isfile(full_path):
        # Fall back to index.html for unknown routes (simple SPA-like behaviour)
        alt = os.path.join(FRONTEND_DIR, "index.html")
        if os.path.isfile(alt) and "." not in os.path.basename(path):
            full_path = alt
        else:
            handler.send_error(404, "File not found")
            return

    content_type, _ = mimetypes.guess_type(full_path)
    content_type = content_type or "application/octet-stream"

    try:
        with open(full_path, "rb") as f:
            data = f.read()
        handler.send_response(200)
        handler.send_header("Content-Type", content_type)
        handler.send_header("Content-Length", str(len(data)))
        handler.end_headers()
        handler.wfile.write(data)
    except OSError:
        handler.send_error(500, "Error reading file")


# --------------------------------------------------------------------------
# Request handler
# --------------------------------------------------------------------------
class GroceryRequestHandler(BaseHTTPRequestHandler):
    server_version = "GroceryShopHTTP/1.0"

    def log_message(self, fmt, *args):
        sys.stderr.write("[%s] %s\n" % (self.log_date_time_string(), fmt % args))

    # ---- generic dispatcher -------------------------------------------------
    def _dispatch(self, method):
        parsed = urlparse(self.path)
        path = parsed.path
        query = parse_qs(parsed.query)

        if path.startswith("/api/"):
            self._handle_api(method, path, query)
        else:
            if method == "GET":
                serve_static(self, path)
            else:
                self.send_error(405, "Method not allowed for static resources")

    def _read_json_body(self):
        length = int(self.headers.get("Content-Length", 0) or 0)
        if length == 0:
            return {}
        raw = self.rfile.read(length)
        if not raw:
            return {}
        try:
            return json.loads(raw.decode("utf-8"))
        except json.JSONDecodeError:
            raise ValidationError("Request body must be valid JSON")

    def _handle_api(self, method, path, query):
        for route_method, regex, func in ROUTES:
            if route_method != method:
                continue
            match = regex.match(path)
            if not match:
                continue

            kwargs = match.groupdict()
            try:
                if method in ("POST", "PUT", "PATCH"):
                    body = self._read_json_body()
                    status, payload = func(self, query, body=body, **kwargs)
                else:
                    status, payload = func(self, query, **kwargs)
                self._send_json(status, payload)
            except ValidationError as e:
                self._send_json(400, {"error": str(e)})
            except NotFoundError as e:
                self._send_json(404, {"error": str(e)})
            except Exception as e:  # pragma: no cover - safety net
                self._send_json(500, {"error": f"Internal server error: {e}"})
            return

        self._send_json(404, {"error": f"No API route for {method} {path}"})

    def _send_json(self, status, payload):
        body = json.dumps(payload, default=str).encode("utf-8")
        self.send_response(status)
        self.send_header("Content-Type", "application/json")
        self.send_header("Content-Length", str(len(body)))
        self.send_header("Access-Control-Allow-Origin", "*")
        self.end_headers()
        self.wfile.write(body)

    # ---- HTTP verbs ---------------------------------------------------------
    def do_GET(self):
        self._dispatch("GET")

    def do_POST(self):
        self._dispatch("POST")

    def do_PUT(self):
        self._dispatch("PUT")

    def do_DELETE(self):
        self._dispatch("DELETE")

    def do_OPTIONS(self):
        self.send_response(204)
        self.send_header("Access-Control-Allow-Origin", "*")
        self.send_header("Access-Control-Allow-Methods", "GET, POST, PUT, DELETE, OPTIONS")
        self.send_header("Access-Control-Allow-Headers", "Content-Type")
        self.end_headers()


def main():
    port = DEFAULT_PORT
    if len(sys.argv) > 1:
        try:
            port = int(sys.argv[1])
        except ValueError:
            print(f"Invalid port '{sys.argv[1]}', using default {DEFAULT_PORT}")

    database.init_db()

    server = ThreadingHTTPServer(("0.0.0.0", port), GroceryRequestHandler)
    print("=" * 60)
    print(" Grocery Shop Management System")
    print(f" Serving on http://localhost:{port}/")
    print(f" Database:  {database.DB_PATH}")
    print(" Press Ctrl+C to stop the server")
    print("=" * 60)
    try:
        server.serve_forever()
    except KeyboardInterrupt:
        print("\nShutting down server...")
        server.shutdown()


if __name__ == "__main__":
    main()
