"""
models.py
---------
All CRUD / business-logic operations for the Grocery Shop Management
System. Every function opens its own short-lived sqlite3 connection,
performs input validation, and raises ValueError on bad input so the
HTTP layer (server.py) can translate that into a clean 400 response.
"""

import sqlite3
from datetime import datetime

from database import get_connection


class ValidationError(ValueError):
    """Raised when input data fails validation."""


class NotFoundError(LookupError):
    """Raised when a requested record does not exist."""


# ---------------------------------------------------------------- helpers --
def _row_to_dict(row):
    return dict(row) if row is not None else None


def _rows_to_list(rows):
    return [dict(r) for r in rows]


def _require(data, fields):
    missing = [f for f in fields if data.get(f) in (None, "")]
    if missing:
        raise ValidationError(f"Missing required field(s): {', '.join(missing)}")


# =============================================================== CATEGORY ==
def list_categories():
    conn = get_connection()
    try:
        rows = conn.execute(
            """SELECT c.*,
                      (SELECT COUNT(*) FROM products p WHERE p.category_id = c.id) AS product_count
               FROM categories c ORDER BY c.name"""
        ).fetchall()
        return _rows_to_list(rows)
    finally:
        conn.close()


def get_category(category_id):
    conn = get_connection()
    try:
        row = conn.execute("SELECT * FROM categories WHERE id = ?", (category_id,)).fetchone()
        if row is None:
            raise NotFoundError(f"Category {category_id} not found")
        return _row_to_dict(row)
    finally:
        conn.close()


def create_category(data):
    _require(data, ["name"])
    conn = get_connection()
    try:
        cur = conn.execute(
            "INSERT INTO categories (name, description) VALUES (?, ?)",
            (data["name"].strip(), data.get("description", "").strip()),
        )
        conn.commit()
        return get_category(cur.lastrowid)
    except sqlite3.IntegrityError:
        raise ValidationError(f"Category '{data['name']}' already exists")
    finally:
        conn.close()


def update_category(category_id, data):
    get_category(category_id)  # ensures existence
    conn = get_connection()
    try:
        current = conn.execute("SELECT * FROM categories WHERE id=?", (category_id,)).fetchone()
        name = data.get("name", current["name"]).strip()
        description = data.get("description", current["description"] or "")
        conn.execute(
            "UPDATE categories SET name = ?, description = ? WHERE id = ?",
            (name, description, category_id),
        )
        conn.commit()
        return get_category(category_id)
    except sqlite3.IntegrityError:
        raise ValidationError(f"Category name '{data.get('name')}' already exists")
    finally:
        conn.close()


def delete_category(category_id):
    get_category(category_id)
    conn = get_connection()
    try:
        conn.execute("UPDATE products SET category_id = NULL WHERE category_id = ?", (category_id,))
        conn.execute("DELETE FROM categories WHERE id = ?", (category_id,))
        conn.commit()
    finally:
        conn.close()


# ================================================================ PRODUCT ==
def list_products(search=None, category_id=None):
    conn = get_connection()
    try:
        query = """SELECT p.*, c.name AS category_name
                   FROM products p LEFT JOIN categories c ON p.category_id = c.id
                   WHERE 1=1"""
        params = []
        if search:
            query += " AND (p.name LIKE ? OR p.description LIKE ?)"
            like = f"%{search}%"
            params += [like, like]
        if category_id:
            query += " AND p.category_id = ?"
            params.append(category_id)
        query += " ORDER BY p.name"
        rows = conn.execute(query, params).fetchall()
        return _rows_to_list(rows)
    finally:
        conn.close()


def get_product(product_id):
    conn = get_connection()
    try:
        row = conn.execute(
            """SELECT p.*, c.name AS category_name
               FROM products p LEFT JOIN categories c ON p.category_id = c.id
               WHERE p.id = ?""",
            (product_id,),
        ).fetchone()
        if row is None:
            raise NotFoundError(f"Product {product_id} not found")
        return _row_to_dict(row)
    finally:
        conn.close()


def _validate_product_numbers(data):
    try:
        price = float(data.get("price"))
        quantity = int(data.get("quantity"))
    except (TypeError, ValueError):
        raise ValidationError("Price must be a number and quantity must be an integer")
    if price < 0:
        raise ValidationError("Price cannot be negative")
    if quantity < 0:
        raise ValidationError("Quantity cannot be negative")
    return price, quantity


def create_product(data):
    _require(data, ["name", "price", "quantity"])
    price, quantity = _validate_product_numbers(data)
    conn = get_connection()
    try:
        cur = conn.execute(
            """INSERT INTO products
               (name, category_id, price, quantity, description, image, low_stock_threshold)
               VALUES (?, ?, ?, ?, ?, ?, ?)""",
            (
                data["name"].strip(),
                data.get("category_id") or None,
                price,
                quantity,
                data.get("description", "").strip(),
                data.get("image", "").strip() or "default",
                int(data.get("low_stock_threshold", 5) or 5),
            ),
        )
        conn.commit()
        return get_product(cur.lastrowid)
    finally:
        conn.close()


def update_product(product_id, data):
    current = get_product(product_id)
    price = data.get("price", current["price"])
    quantity = data.get("quantity", current["quantity"])
    try:
        price = float(price)
        quantity = int(quantity)
    except (TypeError, ValueError):
        raise ValidationError("Price must be a number and quantity must be an integer")
    if price < 0 or quantity < 0:
        raise ValidationError("Price/Quantity cannot be negative")

    conn = get_connection()
    try:
        conn.execute(
            """UPDATE products SET
                 name = ?, category_id = ?, price = ?, quantity = ?,
                 description = ?, image = ?, low_stock_threshold = ?
               WHERE id = ?""",
            (
                data.get("name", current["name"]).strip(),
                data.get("category_id", current["category_id"]) or None,
                price,
                quantity,
                data.get("description", current["description"] or ""),
                data.get("image", current["image"] or "default"),
                int(data.get("low_stock_threshold", current["low_stock_threshold"])),
                product_id,
            ),
        )
        conn.commit()
        return get_product(product_id)
    finally:
        conn.close()


def delete_product(product_id):
    get_product(product_id)
    conn = get_connection()
    try:
        conn.execute("DELETE FROM products WHERE id = ?", (product_id,))
        conn.commit()
    finally:
        conn.close()


def low_stock_products():
    conn = get_connection()
    try:
        rows = conn.execute(
            """SELECT p.*, c.name AS category_name
               FROM products p LEFT JOIN categories c ON p.category_id = c.id
               WHERE p.quantity <= p.low_stock_threshold
               ORDER BY p.quantity ASC"""
        ).fetchall()
        return _rows_to_list(rows)
    finally:
        conn.close()


# =============================================================== CUSTOMER ==
def list_customers():
    conn = get_connection()
    try:
        rows = conn.execute("SELECT * FROM customers ORDER BY name").fetchall()
        return _rows_to_list(rows)
    finally:
        conn.close()


def search_customers(term):
    conn = get_connection()
    try:
        like = f"%{term}%"
        rows = conn.execute(
            """SELECT * FROM customers
               WHERE name LIKE ? OR phone LIKE ? OR email LIKE ?
               ORDER BY name""",
            (like, like, like),
        ).fetchall()
        return _rows_to_list(rows)
    finally:
        conn.close()


def get_customer(customer_id):
    conn = get_connection()
    try:
        row = conn.execute("SELECT * FROM customers WHERE id = ?", (customer_id,)).fetchone()
        if row is None:
            raise NotFoundError(f"Customer {customer_id} not found")
        return _row_to_dict(row)
    finally:
        conn.close()


def find_customer_by_phone(phone):
    conn = get_connection()
    try:
        row = conn.execute("SELECT * FROM customers WHERE phone = ?", (phone,)).fetchone()
        return _row_to_dict(row)
    finally:
        conn.close()


def create_customer(data):
    _require(data, ["name"])
    conn = get_connection()
    try:
        cur = conn.execute(
            "INSERT INTO customers (name, phone, email, address) VALUES (?, ?, ?, ?)",
            (
                data["name"].strip(),
                data.get("phone", "").strip(),
                data.get("email", "").strip(),
                data.get("address", "").strip(),
            ),
        )
        conn.commit()
        return get_customer(cur.lastrowid)
    finally:
        conn.close()


def get_or_create_customer(data):
    """Used at checkout: reuse an existing customer matched by phone, else create one."""
    phone = (data.get("phone") or "").strip()
    if phone:
        existing = find_customer_by_phone(phone)
        if existing:
            return existing
    return create_customer(data)


# ====================================================== ORDERS / BILLING ==
def checkout(data):
    """
    data = {
        "customer": {"name":..., "phone":..., "email":..., "address":...},
        "items": [{"product_id": 1, "quantity": 2}, ...],
        "tax_rate": 0.05   # optional, defaults to 5%
    }
    Validates stock, creates customer/order/order_items/bill, and
    decrements product stock, all inside one transaction.
    """
    customer_data = data.get("customer") or {}
    items = data.get("items") or []
    if not items:
        raise ValidationError("Cart is empty - add at least one item to checkout")
    _require(customer_data, ["name"])

    tax_rate = float(data.get("tax_rate", 0.05))

    conn = get_connection()
    try:
        conn.execute("BEGIN")

        # customer (reuse by phone if given)
        phone = (customer_data.get("phone") or "").strip()
        customer_row = None
        if phone:
            customer_row = conn.execute(
                "SELECT * FROM customers WHERE phone = ?", (phone,)
            ).fetchone()
        if customer_row is None:
            cur = conn.execute(
                "INSERT INTO customers (name, phone, email, address) VALUES (?, ?, ?, ?)",
                (
                    customer_data["name"].strip(),
                    phone,
                    customer_data.get("email", "").strip(),
                    customer_data.get("address", "").strip(),
                ),
            )
            customer_id = cur.lastrowid
        else:
            customer_id = customer_row["id"]

        # validate items & stock, compute subtotal
        subtotal = 0.0
        resolved_items = []
        for item in items:
            product_id = item.get("product_id")
            qty = int(item.get("quantity", 0))
            if not product_id or qty <= 0:
                raise ValidationError("Each cart item needs a valid product_id and quantity")

            product = conn.execute("SELECT * FROM products WHERE id = ?", (product_id,)).fetchone()
            if product is None:
                raise ValidationError(f"Product {product_id} does not exist")
            if product["quantity"] < qty:
                raise ValidationError(
                    f"Insufficient stock for '{product['name']}' "
                    f"(available: {product['quantity']}, requested: {qty})"
                )

            item_subtotal = round(product["price"] * qty, 2)
            subtotal += item_subtotal
            resolved_items.append(
                {
                    "product_id": product_id,
                    "name": product["name"],
                    "price": product["price"],
                    "quantity": qty,
                    "subtotal": item_subtotal,
                }
            )

        tax = round(subtotal * tax_rate, 2)
        total = round(subtotal + tax, 2)

        # create order
        cur = conn.execute(
            "INSERT INTO orders (customer_id, order_date, total_amount) VALUES (?, datetime('now'), ?)",
            (customer_id, total),
        )
        order_id = cur.lastrowid

        # order items + stock decrement
        for it in resolved_items:
            conn.execute(
                """INSERT INTO order_items (order_id, product_id, product_name, quantity, price, subtotal)
                   VALUES (?, ?, ?, ?, ?, ?)""",
                (order_id, it["product_id"], it["name"], it["quantity"], it["price"], it["subtotal"]),
            )
            conn.execute(
                "UPDATE products SET quantity = quantity - ? WHERE id = ?",
                (it["quantity"], it["product_id"]),
            )

        # bill
        bill_number = "BILL-" + datetime.now().strftime("%Y%m%d%H%M%S") + f"-{order_id}"
        conn.execute(
            """INSERT INTO bills (order_id, bill_number, customer_id, subtotal, tax, total_amount, bill_date)
               VALUES (?, ?, ?, ?, ?, ?, datetime('now'))""",
            (order_id, bill_number, customer_id, subtotal, tax, total),
        )

        conn.commit()

        return {
            "order_id": order_id,
            "bill_number": bill_number,
            "customer_id": customer_id,
            "items": resolved_items,
            "subtotal": round(subtotal, 2),
            "tax_rate": tax_rate,
            "tax": tax,
            "total_amount": total,
            "bill_date": datetime.now().isoformat(timespec="seconds"),
        }
    except Exception:
        conn.rollback()
        raise
    finally:
        conn.close()


def list_orders():
    conn = get_connection()
    try:
        rows = conn.execute(
            """SELECT o.id, o.order_date, o.total_amount,
                      c.name AS customer_name, c.phone AS customer_phone,
                      b.bill_number
               FROM orders o
               LEFT JOIN customers c ON o.customer_id = c.id
               LEFT JOIN bills b ON b.order_id = o.id
               ORDER BY o.order_date DESC"""
        ).fetchall()
        return _rows_to_list(rows)
    finally:
        conn.close()


def get_order(order_id):
    conn = get_connection()
    try:
        order = conn.execute(
            """SELECT o.*, c.name AS customer_name, c.phone AS customer_phone,
                      c.email AS customer_email, c.address AS customer_address,
                      b.bill_number, b.subtotal, b.tax, b.total_amount AS bill_total, b.bill_date
               FROM orders o
               LEFT JOIN customers c ON o.customer_id = c.id
               LEFT JOIN bills b ON b.order_id = o.id
               WHERE o.id = ?""",
            (order_id,),
        ).fetchone()
        if order is None:
            raise NotFoundError(f"Order {order_id} not found")
        items = conn.execute(
            "SELECT * FROM order_items WHERE order_id = ?", (order_id,)
        ).fetchall()
        result = _row_to_dict(order)
        result["items"] = _rows_to_list(items)
        return result
    finally:
        conn.close()


# ================================================================ REPORTS ==
def sales_report(date_from=None, date_to=None):
    conn = get_connection()
    try:
        query = "SELECT * FROM bills WHERE 1=1"
        params = []
        if date_from:
            query += " AND date(bill_date) >= date(?)"
            params.append(date_from)
        if date_to:
            query += " AND date(bill_date) <= date(?)"
            params.append(date_to)
        bills = conn.execute(query, params).fetchall()
        bills = _rows_to_list(bills)

        total_sales = round(sum(b["total_amount"] for b in bills), 2)
        total_bills = len(bills)
        total_tax = round(sum(b["tax"] for b in bills), 2)

        # top selling products
        top_query = """
            SELECT oi.product_name, SUM(oi.quantity) AS units_sold,
                   SUM(oi.subtotal) AS revenue
            FROM order_items oi
            JOIN orders o ON oi.order_id = o.id
            JOIN bills b ON b.order_id = o.id
            WHERE 1=1
        """
        top_params = []
        if date_from:
            top_query += " AND date(b.bill_date) >= date(?)"
            top_params.append(date_from)
        if date_to:
            top_query += " AND date(b.bill_date) <= date(?)"
            top_params.append(date_to)
        top_query += " GROUP BY oi.product_name ORDER BY revenue DESC LIMIT 5"
        top_products = _rows_to_list(conn.execute(top_query, top_params).fetchall())

        return {
            "total_sales": total_sales,
            "total_tax": total_tax,
            "total_bills": total_bills,
            "top_products": top_products,
            "bills": bills,
        }
    finally:
        conn.close()
