"""
database.py
-----------
Handles the SQLite connection and schema creation for the
Grocery Shop Management System. No external ORM/framework is used -
plain sqlite3 (Python standard library) only.
"""

import sqlite3
import os

BASE_DIR = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
DB_PATH = os.path.join(BASE_DIR, "database", "grocery.db")


def get_connection():
    """Return a new sqlite3 connection with row access by column name."""
    os.makedirs(os.path.dirname(DB_PATH), exist_ok=True)
    conn = sqlite3.connect(DB_PATH)
    conn.row_factory = sqlite3.Row
    conn.execute("PRAGMA foreign_keys = ON")
    return conn


SCHEMA = """
CREATE TABLE IF NOT EXISTS categories (
    id          INTEGER PRIMARY KEY AUTOINCREMENT,
    name        TEXT NOT NULL UNIQUE,
    description TEXT
);

CREATE TABLE IF NOT EXISTS products (
    id                  INTEGER PRIMARY KEY AUTOINCREMENT,
    name                TEXT NOT NULL,
    category_id         INTEGER,
    price               REAL NOT NULL CHECK (price >= 0),
    quantity            INTEGER NOT NULL DEFAULT 0 CHECK (quantity >= 0),
    description         TEXT,
    image               TEXT,
    low_stock_threshold INTEGER NOT NULL DEFAULT 5,
    FOREIGN KEY (category_id) REFERENCES categories(id) ON DELETE SET NULL
);

CREATE TABLE IF NOT EXISTS customers (
    id         INTEGER PRIMARY KEY AUTOINCREMENT,
    name       TEXT NOT NULL,
    phone      TEXT,
    email      TEXT,
    address    TEXT,
    created_at TEXT DEFAULT (datetime('now'))
);

CREATE TABLE IF NOT EXISTS orders (
    id           INTEGER PRIMARY KEY AUTOINCREMENT,
    customer_id  INTEGER,
    order_date   TEXT DEFAULT (datetime('now')),
    total_amount REAL,
    FOREIGN KEY (customer_id) REFERENCES customers(id) ON DELETE SET NULL
);

CREATE TABLE IF NOT EXISTS order_items (
    id           INTEGER PRIMARY KEY AUTOINCREMENT,
    order_id     INTEGER NOT NULL,
    product_id   INTEGER,
    product_name TEXT NOT NULL,
    quantity     INTEGER NOT NULL,
    price        REAL NOT NULL,
    subtotal     REAL NOT NULL,
    FOREIGN KEY (order_id) REFERENCES orders(id) ON DELETE CASCADE,
    FOREIGN KEY (product_id) REFERENCES products(id) ON DELETE SET NULL
);

CREATE TABLE IF NOT EXISTS bills (
    id            INTEGER PRIMARY KEY AUTOINCREMENT,
    order_id      INTEGER,
    bill_number   TEXT UNIQUE,
    customer_id   INTEGER,
    subtotal      REAL NOT NULL,
    tax           REAL NOT NULL,
    total_amount  REAL NOT NULL,
    bill_date     TEXT DEFAULT (datetime('now')),
    FOREIGN KEY (order_id) REFERENCES orders(id) ON DELETE CASCADE,
    FOREIGN KEY (customer_id) REFERENCES customers(id) ON DELETE SET NULL
);
"""

SEED_CATEGORIES = [
    ("Fruits & Vegetables", "Fresh fruits and vegetables sourced daily"),
    ("Dairy & Eggs", "Milk, cheese, yogurt and farm eggs"),
    ("Bakery", "Fresh bread, cakes and pastries"),
    ("Beverages", "Juices, soft drinks and water"),
    ("Snacks", "Chips, biscuits and namkeen"),
    ("Grains & Pulses", "Rice, wheat, dal and cereals"),
]

SEED_PRODUCTS = [
    # name, category index (1-based), price, quantity, description, image, low_stock_threshold
    ("Fresh Apples (1kg)", 1, 180, 50, "Crisp and juicy red apples.", "apple", 10),
    ("Banana (1 dozen)", 1, 60, 80, "Ripe, naturally sweet bananas.", "banana", 10),
    ("Tomato (1kg)", 1, 40, 100, "Fresh, farm-picked tomatoes.", "tomato", 15),
    ("Potato (1kg)", 1, 30, 120, "Farm fresh potatoes.", "potato", 15),
    ("Carrot (1kg)", 1, 45, 60, "Crunchy orange carrots.", "carrot", 10),
    ("Toned Milk (1L)", 2, 58, 60, "Fresh toned milk, pasteurized daily.", "milk", 10),
    ("Cheese Slices (200g)", 2, 120, 40, "Creamy processed cheese slices.", "cheese", 5),
    ("Farm Eggs (12 pcs)", 2, 84, 45, "Fresh brown farm eggs.", "egg", 8),
    ("Curd (500g)", 2, 40, 55, "Thick and fresh homestyle curd.", "curd", 8),
    ("Whole Wheat Bread", 3, 45, 35, "Soft whole-wheat bread loaf.", "bread", 8),
    ("Chocolate Cake (500g)", 3, 299, 15, "Rich chocolate sponge cake.", "cake", 4),
    ("Butter Croissant", 3, 55, 30, "Flaky, buttery croissants.", "croissant", 6),
    ("Orange Juice (1L)", 4, 110, 50, "100% natural orange juice.", "juice", 8),
    ("Mineral Water (1L)", 4, 20, 200, "Packaged drinking water.", "water", 30),
    ("Cola (750ml)", 4, 45, 90, "Chilled fizzy cola drink.", "soda", 15),
    ("Potato Chips (100g)", 5, 30, 90, "Crispy salted potato chips.", "chips", 15),
    ("Digestive Biscuits", 5, 45, 70, "Wholesome digestive biscuits.", "biscuit", 10),
    ("Roasted Peanuts (200g)", 5, 60, 50, "Crunchy roasted, salted peanuts.", "peanuts", 8),
    ("Basmati Rice (5kg)", 6, 450, 25, "Premium long-grain basmati rice.", "rice", 5),
    ("Toor Dal (1kg)", 6, 140, 40, "Good quality toor dal.", "dal", 8),
    ("Wheat Flour (5kg)", 6, 210, 30, "Stone-ground whole wheat flour.", "flour", 6),
]


def seed_data(conn):
    """Insert demo categories and products the first time the DB is created."""
    cur = conn.cursor()
    cur.executemany(
        "INSERT INTO categories (name, description) VALUES (?, ?)", SEED_CATEGORIES
    )
    conn.commit()

    for name, cat_idx, price, qty, desc, image, threshold in SEED_PRODUCTS:
        cur.execute(
            """INSERT INTO products
               (name, category_id, price, quantity, description, image, low_stock_threshold)
               VALUES (?, ?, ?, ?, ?, ?, ?)""",
            (name, cat_idx, price, qty, desc, image, threshold),
        )
    conn.commit()


def init_db():
    """Create tables if they do not exist, and seed demo data on first run."""
    conn = get_connection()
    conn.executescript(SCHEMA)
    conn.commit()

    cur = conn.cursor()
    cur.execute("SELECT COUNT(*) AS c FROM categories")
    if cur.fetchone()["c"] == 0:
        seed_data(conn)

    conn.close()


if __name__ == "__main__":
    init_db()
    print("Database initialised at:", DB_PATH)
